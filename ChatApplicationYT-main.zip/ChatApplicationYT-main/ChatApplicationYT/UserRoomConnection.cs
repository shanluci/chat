namespace ChatApplicationYT;

public class UserRoomConnection
{
    public string? User { get; set; }
    public string? Room { get; set; }
}